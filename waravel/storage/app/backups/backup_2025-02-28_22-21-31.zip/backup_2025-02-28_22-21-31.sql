--
-- PostgreSQL database dump
--

-- Dumped from database version 17.3 (Debian 17.3-1.pgdg120+1)
-- Dumped by pg_dump version 17.3 (Ubuntu 17.3-1.pgdg24.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: cache; Type: TABLE; Schema: public; Owner: sail
--

CREATE TABLE public.cache (
    key character varying(255) NOT NULL,
    value text NOT NULL,
    expiration integer NOT NULL
);


ALTER TABLE public.cache OWNER TO sail;

--
-- Name: cache_locks; Type: TABLE; Schema: public; Owner: sail
--

CREATE TABLE public.cache_locks (
    key character varying(255) NOT NULL,
    owner character varying(255) NOT NULL,
    expiration integer NOT NULL
);


ALTER TABLE public.cache_locks OWNER TO sail;

--
-- Name: cliente_favoritos; Type: TABLE; Schema: public; Owner: sail
--

CREATE TABLE public.cliente_favoritos (
    id bigint NOT NULL,
    cliente_id bigint NOT NULL,
    producto_id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.cliente_favoritos OWNER TO sail;

--
-- Name: cliente_favoritos_id_seq; Type: SEQUENCE; Schema: public; Owner: sail
--

CREATE SEQUENCE public.cliente_favoritos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cliente_favoritos_id_seq OWNER TO sail;

--
-- Name: cliente_favoritos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sail
--

ALTER SEQUENCE public.cliente_favoritos_id_seq OWNED BY public.cliente_favoritos.id;


--
-- Name: clientes; Type: TABLE; Schema: public; Owner: sail
--

CREATE TABLE public.clientes (
    id bigint NOT NULL,
    guid character varying(11) NOT NULL,
    nombre character varying(255) NOT NULL,
    apellido character varying(255) NOT NULL,
    avatar character varying(255) NOT NULL,
    telefono character varying(255) NOT NULL,
    direccion json NOT NULL,
    activo boolean DEFAULT true NOT NULL,
    usuario_id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.clientes OWNER TO sail;

--
-- Name: clientes_id_seq; Type: SEQUENCE; Schema: public; Owner: sail
--

CREATE SEQUENCE public.clientes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.clientes_id_seq OWNER TO sail;

--
-- Name: clientes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sail
--

ALTER SEQUENCE public.clientes_id_seq OWNED BY public.clientes.id;


--
-- Name: failed_jobs; Type: TABLE; Schema: public; Owner: sail
--

CREATE TABLE public.failed_jobs (
    id bigint NOT NULL,
    uuid character varying(255) NOT NULL,
    connection text NOT NULL,
    queue text NOT NULL,
    payload text NOT NULL,
    exception text NOT NULL,
    failed_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.failed_jobs OWNER TO sail;

--
-- Name: failed_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: sail
--

CREATE SEQUENCE public.failed_jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.failed_jobs_id_seq OWNER TO sail;

--
-- Name: failed_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sail
--

ALTER SEQUENCE public.failed_jobs_id_seq OWNED BY public.failed_jobs.id;


--
-- Name: job_batches; Type: TABLE; Schema: public; Owner: sail
--

CREATE TABLE public.job_batches (
    id character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    total_jobs integer NOT NULL,
    pending_jobs integer NOT NULL,
    failed_jobs integer NOT NULL,
    failed_job_ids text NOT NULL,
    options text,
    cancelled_at integer,
    created_at integer NOT NULL,
    finished_at integer
);


ALTER TABLE public.job_batches OWNER TO sail;

--
-- Name: jobs; Type: TABLE; Schema: public; Owner: sail
--

CREATE TABLE public.jobs (
    id bigint NOT NULL,
    queue character varying(255) NOT NULL,
    payload text NOT NULL,
    attempts smallint NOT NULL,
    reserved_at integer,
    available_at integer NOT NULL,
    created_at integer NOT NULL
);


ALTER TABLE public.jobs OWNER TO sail;

--
-- Name: jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: sail
--

CREATE SEQUENCE public.jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.jobs_id_seq OWNER TO sail;

--
-- Name: jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sail
--

ALTER SEQUENCE public.jobs_id_seq OWNED BY public.jobs.id;


--
-- Name: migrations; Type: TABLE; Schema: public; Owner: sail
--

CREATE TABLE public.migrations (
    id integer NOT NULL,
    migration character varying(255) NOT NULL,
    batch integer NOT NULL
);


ALTER TABLE public.migrations OWNER TO sail;

--
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: sail
--

CREATE SEQUENCE public.migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.migrations_id_seq OWNER TO sail;

--
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sail
--

ALTER SEQUENCE public.migrations_id_seq OWNED BY public.migrations.id;


--
-- Name: password_reset_tokens; Type: TABLE; Schema: public; Owner: sail
--

CREATE TABLE public.password_reset_tokens (
    email character varying(255) NOT NULL,
    token character varying(255) NOT NULL,
    created_at timestamp(0) without time zone
);


ALTER TABLE public.password_reset_tokens OWNER TO sail;

--
-- Name: productos; Type: TABLE; Schema: public; Owner: sail
--

CREATE TABLE public.productos (
    id bigint NOT NULL,
    guid character varying(11) NOT NULL,
    vendedor_id bigint NOT NULL,
    nombre character varying(255) NOT NULL,
    descripcion text NOT NULL,
    "estadoFisico" character varying(255) NOT NULL,
    precio numeric(8,2) NOT NULL,
    stock integer NOT NULL,
    categoria character varying(255) NOT NULL,
    estado character varying(255) NOT NULL,
    imagenes json NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT productos_categoria_check CHECK (((categoria)::text = ANY ((ARRAY['Tecnologia'::character varying, 'Ropa'::character varying, 'Hogar'::character varying, 'Coleccionismo'::character varying, 'Vehiculos'::character varying, 'Videojuegos'::character varying, 'Musica'::character varying, 'Deporte'::character varying, 'Cine'::character varying, 'Cocina'::character varying])::text[]))),
    CONSTRAINT "productos_estadoFisico_check" CHECK ((("estadoFisico")::text = ANY ((ARRAY['Nuevo'::character varying, 'Usado'::character varying, 'Deteriorado'::character varying])::text[]))),
    CONSTRAINT productos_estado_check CHECK (((estado)::text = ANY ((ARRAY['Disponible'::character varying, 'Vendido'::character varying, 'Desactivado'::character varying, 'Baneado'::character varying])::text[])))
);


ALTER TABLE public.productos OWNER TO sail;

--
-- Name: productos_id_seq; Type: SEQUENCE; Schema: public; Owner: sail
--

CREATE SEQUENCE public.productos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.productos_id_seq OWNER TO sail;

--
-- Name: productos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sail
--

ALTER SEQUENCE public.productos_id_seq OWNED BY public.productos.id;


--
-- Name: sessions; Type: TABLE; Schema: public; Owner: sail
--

CREATE TABLE public.sessions (
    id character varying(255) NOT NULL,
    user_id bigint,
    ip_address character varying(45),
    user_agent text,
    payload text NOT NULL,
    last_activity integer NOT NULL
);


ALTER TABLE public.sessions OWNER TO sail;

--
-- Name: users; Type: TABLE; Schema: public; Owner: sail
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    guid character varying(11) NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    email_verified_at timestamp(0) without time zone,
    password character varying(255) NOT NULL,
    role character varying(255) DEFAULT 'user'::character varying NOT NULL,
    remember_token character varying(100),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    password_reset_token character varying(255),
    password_reset_expires_at timestamp(0) without time zone,
    CONSTRAINT users_role_check CHECK (((role)::text = ANY ((ARRAY['user'::character varying, 'cliente'::character varying, 'admin'::character varying])::text[])))
);


ALTER TABLE public.users OWNER TO sail;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: sail
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO sail;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sail
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: valoraciones; Type: TABLE; Schema: public; Owner: sail
--

CREATE TABLE public.valoraciones (
    id bigint NOT NULL,
    guid character varying(11) NOT NULL,
    comentario character varying(255) NOT NULL,
    puntuacion integer NOT NULL,
    "clienteValorado_id" bigint NOT NULL,
    autor_id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.valoraciones OWNER TO sail;

--
-- Name: valoraciones_id_seq; Type: SEQUENCE; Schema: public; Owner: sail
--

CREATE SEQUENCE public.valoraciones_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.valoraciones_id_seq OWNER TO sail;

--
-- Name: valoraciones_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sail
--

ALTER SEQUENCE public.valoraciones_id_seq OWNED BY public.valoraciones.id;


--
-- Name: ventas; Type: TABLE; Schema: public; Owner: sail
--

CREATE TABLE public.ventas (
    id bigint NOT NULL,
    guid character varying(11) NOT NULL,
    estado character varying(255) NOT NULL,
    comprador json NOT NULL,
    "lineaVentas" json NOT NULL,
    "precioTotal" double precision NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.ventas OWNER TO sail;

--
-- Name: ventas_id_seq; Type: SEQUENCE; Schema: public; Owner: sail
--

CREATE SEQUENCE public.ventas_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ventas_id_seq OWNER TO sail;

--
-- Name: ventas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sail
--

ALTER SEQUENCE public.ventas_id_seq OWNED BY public.ventas.id;


--
-- Name: cliente_favoritos id; Type: DEFAULT; Schema: public; Owner: sail
--

ALTER TABLE ONLY public.cliente_favoritos ALTER COLUMN id SET DEFAULT nextval('public.cliente_favoritos_id_seq'::regclass);


--
-- Name: clientes id; Type: DEFAULT; Schema: public; Owner: sail
--

ALTER TABLE ONLY public.clientes ALTER COLUMN id SET DEFAULT nextval('public.clientes_id_seq'::regclass);


--
-- Name: failed_jobs id; Type: DEFAULT; Schema: public; Owner: sail
--

ALTER TABLE ONLY public.failed_jobs ALTER COLUMN id SET DEFAULT nextval('public.failed_jobs_id_seq'::regclass);


--
-- Name: jobs id; Type: DEFAULT; Schema: public; Owner: sail
--

ALTER TABLE ONLY public.jobs ALTER COLUMN id SET DEFAULT nextval('public.jobs_id_seq'::regclass);


--
-- Name: migrations id; Type: DEFAULT; Schema: public; Owner: sail
--

ALTER TABLE ONLY public.migrations ALTER COLUMN id SET DEFAULT nextval('public.migrations_id_seq'::regclass);


--
-- Name: productos id; Type: DEFAULT; Schema: public; Owner: sail
--

ALTER TABLE ONLY public.productos ALTER COLUMN id SET DEFAULT nextval('public.productos_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: sail
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: valoraciones id; Type: DEFAULT; Schema: public; Owner: sail
--

ALTER TABLE ONLY public.valoraciones ALTER COLUMN id SET DEFAULT nextval('public.valoraciones_id_seq'::regclass);


--
-- Name: ventas id; Type: DEFAULT; Schema: public; Owner: sail
--

ALTER TABLE ONLY public.ventas ALTER COLUMN id SET DEFAULT nextval('public.ventas_id_seq'::regclass);


--
-- Data for Name: cache; Type: TABLE DATA; Schema: public; Owner: sail
--

COPY public.cache (key, value, expiration) FROM stdin;
\.


--
-- Data for Name: cache_locks; Type: TABLE DATA; Schema: public; Owner: sail
--

COPY public.cache_locks (key, owner, expiration) FROM stdin;
\.


--
-- Data for Name: cliente_favoritos; Type: TABLE DATA; Schema: public; Owner: sail
--

COPY public.cliente_favoritos (id, cliente_id, producto_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: clientes; Type: TABLE DATA; Schema: public; Owner: sail
--

COPY public.clientes (id, guid, nombre, apellido, avatar, telefono, direccion, activo, usuario_id, created_at, updated_at) FROM stdin;
1	2G6HueqixE5	Juan	Perez	clientes/avatar.png	612345678	{"calle":"Avenida Siempre Viva","numero":742,"piso":1,"letra":"A","codigoPostal":28001}	t	3	2025-02-28 21:18:42	2025-02-28 21:18:42
2	DU6jCZtareb	Maria	Garcia	clientes/avatar.png	987654321	{"calle":"Calle de las Nubes","numero":123,"piso":3,"letra":"C","codigoPostal":28971}	t	4	2025-02-28 21:18:42	2025-02-28 21:18:42
3	yEC3KBt6CFY	Pedro	Martinez	clientes/avatar.png	321456789	{"calle":"Avenida Espa\\u00f1a","numero":456,"piso":3,"letra":"B","codigoPostal":28970}	f	5	2025-02-28 21:18:42	2025-02-28 21:18:42
4	X9vB7LpQ2ZM	Laura	Gómez	clientes/avatar.png	611223344	{"calle":"Calle del R\\u00edo","numero":10,"piso":2,"letra":"B","codigoPostal":28003}	t	6	2025-02-28 21:18:42	2025-02-28 21:18:42
5	G5Yt9XqK8VL	Diego	Ruiz	clientes/avatar.png	622334455	{"calle":"Calle del Bosque","numero":15,"piso":1,"letra":"A","codigoPostal":28004}	t	7	2025-02-28 21:18:42	2025-02-28 21:18:42
6	J2pM6ZcQ4BR	Sofía	López	clientes/avatar.png	633445566	{"calle":"Calle del Mar","numero":20,"piso":3,"letra":"C","codigoPostal":28005}	t	8	2025-02-28 21:18:42	2025-02-28 21:18:42
7	W7Xn3TfY9KD	Javier	Torres	clientes/avatar.png	644556677	{"calle":"Calle del Sol","numero":25,"piso":4,"letra":"D","codigoPostal":28006}	t	9	2025-02-28 21:18:42	2025-02-28 21:18:42
8	P8Lq5VZK2YM	Laura	Castro	clientes/avatar.png	655667788	{"calle":"Calle de la Monta\\u00f1a","numero":30,"piso":5,"letra":"E","codigoPostal":28007}	t	10	2025-02-28 21:18:42	2025-02-28 21:18:42
9	M4B9XQK7YtN	Ana	Lopez	clientes/avatar.png	654321987	{"calle":"Calle del Sol","numero":789,"piso":2,"letra":"D","codigoPostal":28002}	t	11	2025-02-28 21:18:42	2025-02-28 21:18:42
10	Z6TQ8LpX5YV	Carlos	Fernandez	clientes/avatar.png	987123654	{"calle":"Calle de la Luna","numero":321,"piso":4,"letra":"E","codigoPostal":28972}	t	12	2025-02-28 21:18:42	2025-02-28 21:18:42
11	X9KpL3YV7QT	Isabella	Rodriguez	clientes/avatar.png	321987654	{"calle":"Avenida de las Estrellas","numero":654,"piso":5,"letra":"F","codigoPostal":28973}	t	13	2025-02-28 21:18:42	2025-02-28 21:18:42
12	B6YtQ8XZ5LM	Jose	Luis	clientes/avatar.png	654789321	{"calle":"Calle del Cielo","numero":987,"piso":6,"letra":"G","codigoPostal":28974}	t	14	2025-02-28 21:18:42	2025-02-28 21:18:42
\.


--
-- Data for Name: failed_jobs; Type: TABLE DATA; Schema: public; Owner: sail
--

COPY public.failed_jobs (id, uuid, connection, queue, payload, exception, failed_at) FROM stdin;
\.


--
-- Data for Name: job_batches; Type: TABLE DATA; Schema: public; Owner: sail
--

COPY public.job_batches (id, name, total_jobs, pending_jobs, failed_jobs, failed_job_ids, options, cancelled_at, created_at, finished_at) FROM stdin;
\.


--
-- Data for Name: jobs; Type: TABLE DATA; Schema: public; Owner: sail
--

COPY public.jobs (id, queue, payload, attempts, reserved_at, available_at, created_at) FROM stdin;
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: sail
--

COPY public.migrations (id, migration, batch) FROM stdin;
1	0001_01_01_000000_create_users_table	1
2	0001_01_01_000001_create_cache_table	1
3	0001_01_01_000002_create_jobs_table	1
4	2025_02_14_165112_create_clientes_table	1
5	2025_02_14_165136_create_productos_table	1
6	2025_02_14_165313_create_valoraciones_table	1
7	2025_02_15_134258_create_cliente_favoritos_table	1
8	2025_02_17_191112_create_venta_table	1
\.


--
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: public; Owner: sail
--

COPY public.password_reset_tokens (email, token, created_at) FROM stdin;
\.


--
-- Data for Name: productos; Type: TABLE DATA; Schema: public; Owner: sail
--

COPY public.productos (id, guid, vendedor_id, nombre, descripcion, "estadoFisico", precio, stock, categoria, estado, imagenes, created_at, updated_at) FROM stdin;
1	G4YXT9K5QLV	1	Portátil Gamer	Este potente portátil está diseñado para gaming de alto rendimiento y tareas exigentes como edición de video y modelado 3D. Equipado con un procesador de última generación, tarjeta gráfica dedicada y una pantalla de alta frecuencia de actualización, ofrece una experiencia fluida tanto para jugadores como para profesionales.	Nuevo	800.00	100	Tecnologia	Disponible	["productos\\/portatil1.webp","productos\\/portatil2.webp"]	2025-02-28 21:18:42	2025-02-28 21:18:42
2	Z8K3VLYTQ72	2	Chaqueta de Cuero	Chaqueta de cuero genuino con un diseño clásico y sofisticado. Ideal para quienes buscan un look elegante sin sacrificar comodidad y protección contra el frío. Su forro interior aporta calidez, mientras que su material resistente garantiza una larga durabilidad.	Usado	15.00	100	Ropa	Disponible	["productos\\/chaqueta1.webp"]	2025-02-28 21:18:42	2025-02-28 21:18:42
3	QX9T7LK5VY3	3	Guitarra Eléctrica	Guitarra eléctrica de cuerpo sólido con un diseño clásico y un sonido potente. Perfecta para músicos de cualquier nivel que buscan un instrumento versátil para rock, blues, jazz y más. Aunque presenta signos de uso, su sonido sigue siendo excepcional y está lista para conectar y tocar.	Deteriorado	300.00	100	Musica	Disponible	["productos\\/guitarra1.webp","productos\\/guitarra2.webp"]	2025-02-28 21:18:42	2025-02-28 21:18:42
4	VYQ8XK4T9L5	1	Pantalones Vaqueros	Pantalones vaqueros de alta calidad, confeccionados con tela resistente y un ajuste cómodo. Ideales para el día a día o para combinarlos con distintos estilos. Su diseño clásico nunca pasa de moda y su durabilidad los hace una opción excelente para cualquier guardarropa.	Nuevo	10.00	100	Ropa	Disponible	["productos\\/pantalones1.webp","productos\\/pantalones2.webp"]	2025-02-28 21:18:42	2025-02-28 21:18:42
5	T3K9QLYV7X5	2	Mario Party 8	Divertido juego de fiesta para toda la familia. Mario Party 8 ofrece una gran variedad de minijuegos y tableros interactivos que garantizan horas de entretenimiento. Perfecto para jugar solo o en compañía de amigos y familiares, este título es un clásico de la saga de Nintendo.	Nuevo	50.00	100	Videojuegos	Disponible	["productos\\/mario1.webp","productos\\/mario2.webp"]	2025-02-28 21:18:42	2025-02-28 21:18:42
6	L5X7YQT9VK3	3	Consola Xbox Series X	La consola de nueva generación de Microsoft con un rendimiento excepcional. Disfruta de gráficos en 4K, tiempos de carga ultrarrápidos y una biblioteca de juegos extensa. Ideal para quienes buscan la mejor experiencia en videojuegos y entretenimiento en casa.	Nuevo	250.00	100	Videojuegos	Disponible	["productos\\/xbox1.webp","productos\\/xbox2.webp"]	2025-02-28 21:18:42	2025-02-28 21:18:42
7	X8KQ5T9YLV7	2	Set de Púas para Guitarra	Paquete de 12 púas de diferentes grosores y materiales, ideales para distintos estilos musicales. Perfectas para guitarras acústicas y eléctricas.	Nuevo	5.00	100	Musica	Disponible	["productos\\/puas1.webp","productos\\/puas2.webp"]	2025-02-28 21:18:42	2025-02-28 21:18:42
8	Y9VQXK37TL5	2	Amplificador Fender 40W	Amplificador Fender de 40W con ecualización ajustable y efectos de reverberación. Ideal para ensayos y pequeñas presentaciones en vivo.	Usado	120.00	100	Musica	Disponible	["productos\\/ampli1.webp","productos\\/ampli2.webp"]	2025-02-28 21:18:42	2025-02-28 21:18:42
9	K7YLTQ9X5V3	1	Batería Electrónica Roland	Kit de batería electrónica con pads sensibles al tacto, módulo de sonidos y conexión MIDI para grabaciones digitales.	Nuevo	600.00	100	Musica	Disponible	["productos\\/bateria1.webp","productos\\/bateria2.webp"]	2025-02-28 21:18:42	2025-02-28 21:18:42
10	QX5V9KY3TL7	3	Smartwatch Xiaomi Mi Band 7	Reloj inteligente con monitor de actividad física, sensor de frecuencia cardíaca y notificaciones de smartphone.	Nuevo	50.00	100	Tecnologia	Disponible	["productos\\/smartwatch1.webp"]	2025-02-28 21:18:42	2025-02-28 21:18:42
11	X9YT7KQLV53	3	Zapatillas Adidas Running	Zapatillas deportivas con suela de espuma de alto rendimiento. Comodidad y soporte ideal para correr largas distancias.	Nuevo	70.00	100	Ropa	Disponible	["productos\\/zapatillas1.webp","productos\\/zapatillas2.webp"]	2025-02-28 21:18:42	2025-02-28 21:18:42
12	7K5TQL9XYV3	2	Lámpara LED Inteligente	Lámpara de escritorio con luz LED regulable y control táctil. Compatible con asistentes de voz como Alexa y Google Home.	Nuevo	30.00	100	Hogar	Disponible	["productos\\/lampara1.webp"]	2025-02-28 21:18:42	2025-02-28 21:18:42
13	TQ9K7XY5LV3	1	The Legend of Zelda: Breath of the Wild	Juego de aventura y exploración para Nintendo Switch con un mundo abierto enorme y mecánicas innovadoras.	Nuevo	55.00	100	Videojuegos	Disponible	["productos\\/zelda1.webp","productos\\/zelda2.webp"]	2025-02-28 21:18:42	2025-02-28 21:18:42
14	V3XKYQ9T57L	1	Colección de Blu-ray Star Wars	Edición especial en Blu-ray de la saga completa de Star Wars, con contenido exclusivo y material detrás de cámaras.	Usado	80.00	100	Cine	Disponible	["productos\\/starwars1.webp","productos\\/starwars2.webp"]	2025-02-28 21:18:42	2025-02-28 21:18:42
15	5KQYT79XLV3	3	Cafetera Espresso Automática	Cafetera con molinillo integrado y sistema de espumado de leche. Perfecta para preparar café de calidad en casa.	Nuevo	150.00	100	Cocina	Disponible	["productos\\/cafetera1.webp","productos\\/cafetera2.webp"]	2025-02-28 21:18:42	2025-02-28 21:18:42
16	XK5VQT9Y3L7	1	Figura de Acción Spider-Man	Figura coleccionable de Spider-Man en edición especial con detalles realistas y articulaciones móviles.	Nuevo	40.00	100	Coleccionismo	Disponible	["productos\\/spiderman1.webp"]	2025-02-28 21:18:42	2025-02-28 21:18:42
17	YQ7LXK9V53T	9	Monitor Gaming 27"	Monitor de 27 pulgadas con tasa de refresco de 144Hz y resolución QHD. Ideal para gaming y diseño gráfico.	Nuevo	300.00	10	Tecnologia	Disponible	["productos\\/monitor1.webp","productos\\/monitor2.webp"]	2025-02-28 21:18:42	2025-02-28 21:18:42
18	K9QXT7VYL53	8	Teclado Mecánico RGB	Teclado mecánico con retroiluminación RGB y switches Cherry MX. Perfecto para gamers y programadores.	Nuevo	120.00	15	Tecnologia	Disponible	["productos\\/teclado1.webp","productos\\/teclado2.webp"]	2025-02-28 21:18:42	2025-02-28 21:18:42
19	T5YXQK9L73V	7	Silla Gaming Ergonómica	Silla ergonómica con soporte lumbar y reposacabezas ajustable. Ideal para largas sesiones de gaming o trabajo.	Nuevo	200.00	5	Hogar	Disponible	["productos\\/silla1.webp","productos\\/silla2.webp"]	2025-02-28 21:18:42	2025-02-28 21:18:42
20	9X7TQY5KVL3	6	Auriculares Inalámbricos	Auriculares con cancelación de ruido y sonido envolvente. Perfectos para música y llamadas.	Nuevo	150.00	20	Tecnologia	Disponible	["productos\\/auriculares1.webp","productos\\/auriculares2.webp"]	2025-02-28 21:18:42	2025-02-28 21:18:42
21	QKYX9T753LV	5	Mesa de Oficina	Mesa de oficina con diseño moderno y espacio amplio. Ideal para trabajar desde casa.	Nuevo	180.00	8	Hogar	Disponible	["productos\\/mesa1.webp","productos\\/mesa2.webp"]	2025-02-28 21:18:42	2025-02-28 21:18:42
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: sail
--

COPY public.sessions (id, user_id, ip_address, user_agent, payload, last_activity) FROM stdin;
9E9wnTEPSXVNQIXew4ERZhgLMnkTPXnp85DJck6X	17	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36	ZXlKcGRpSTZJalJQV0d0MlIyTllTMHBDT1RoVGVYSmpORzFYZWxFOVBTSXNJblpoYkhWbElqb2lSWEF6Tm5FeWNEVjZjRU56ZUZwQlQxcE1VVTlRUVM5UlMzbFVOMGszTjA1bU5WSldiRmRrWWxWdUszRkRUaTlwTldOWk9HVXJUR0o2VTBGdVNWWkpSbGN3UkVSaVJsaHNVU3N2YjNZelMwWmhaeXR1YlM4MWRGWkhPVmwzYzNabk5EUkVOamxwVHpNeVEzcExZMnhoT0cwMWVtZEdiMHAxUkVGbFNGTnlTbXRzVjBGallWaGtlRkZIWjJGUmFGbFFiR05pVUdWTGJDOUdTR3N2Y0dwekwzRXJja2hFYzI1TE0wRXJTV1EwTTNoWk5uQkxPWFkzY25Vd01scDZVWE1yYnpWMU5WRnJNbEUzZEdVNFIxZ3dkMEZTWkdscWFIRXlXVWMxYWpkeFMzQTBRV04xTkRGRVkzQk1WVWQxUkN0VVJ6ZGFRVFZaTWtKTVNEQjRVelJXWkZSNFkyTjRNVnBQWlRocVluRmphR1JGY1ZGc2VHMUlZak5rT1Vwb09IbEtUekJ0WjFOck5ETm9lRUpUVDBobFp6QlNSRnB4V21Gb01EZDFRWFZEY21wVFFtSXpNbmQxTnpNd1JsWTJXSHBJYTIxdFowRXhkSGRMVm1aMVlUUkZObVJMV1ZoaVZrVkZjMUpWUFNJc0ltMWhZeUk2SWpGak1UWmlObVV5TURJM05qZ3dOemxpTWpjMFpURTFOalV6TWpGbE5HSTVNMlExTW1RMk9UUmhPRFF6TlRjeFlqTXdNMlUwTm1WaFpUTTVZelUwTXpNaUxDSjBZV2NpT2lJaWZRPT0=	1740777674
Riz90U3p9lFvTQiHD5QA3d4HIhq2GzAvSjbUrh8y	4	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36	ZXlKcGRpSTZJbVZrWlZSdGJXZFlabVpETVV0SU0wdGtZbWhwYVVFOVBTSXNJblpoYkhWbElqb2lRamREZGtjM1RIZzJSVkZwYUhCUloxa3pWblU1VDBScE1WVllla2ROUkdSNFpqVlhVRVIwWTNwSWMweERVM2RDV2pKSVdrNU1TVkl4TTAwMVVVNDFRMlpaT1ROU1JrZHhkRGRZYkd0V1FUQjVPRU5rZURCNGNqVXhTbEJwWm1WWWVFeGFiRzFuVFRaSVRHRnphMEpCZEc5VVl6ZElUMW95ZUdweVFuazJaVmRpTDFCVGVGYzRjREoxUkRWMFJrUjFUekprWkVVdmJUazFXbk5CVFVZNU1rOXVlR2RyUlhoTVZGTmFUelpPWlZaTE9YTjRPVXBzY0hoME5XMXNTMk5zYzI5RGJGZzJRazVuUW1OTldVcHJSbUZ3T0M5RFF5ODVhWE5WUW5BeFNuUmpSakZOWnpWbmRGRnBXSGdyVFc1UVNIbG9aVkpVZVZSamVsTkRUak5yYjJkS1JrZDBMM2xuY25Oa2RVWnpSRWt5U1V3MmJsZzFMMkozYjNWWGFESkJiMEZVY0dWQ1FubHdTVVYxTm05bE5ERkxha3RTUjBwUVQwOXVZMlUwZDJ4aWVWcHpZVzAwT1ROV1ZWRllXbXhYYUZWVk1WbDZWREV6WTBaV2VFZEJjWFpsZHk5RGNFVmtkRzF2UFNJc0ltMWhZeUk2SWpVeU9HUmhNalF5WVRWa1lqUmxNek0zTURsa05tUm1ZMlkxWWpjeU5tWmxNRFpqWVRSbVl6WXpNMkU0TldSaFltTTBaVEEyWkRZMU0yWTRaV0pqWXpFaUxDSjBZV2NpT2lJaWZRPT0=	1740777133
bHSDwJbp2i671Hnl1gBPsX7GptkA8oT1w1xbDfSH	\N	172.18.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36 Edg/133.0.0.0	ZXlKcGRpSTZJbFJQTjNsVVYycDBlSE5oTW5CNlN6WkNhR2xaYmxFOVBTSXNJblpoYkhWbElqb2lXR3B1TjA5MVpHcGFhWGQxWVRKbE5tc3ZWWFZWU2tOWFpqaFFaWGhIVW1OdWVXUlVUUzl3Y2tOdmQwTllRbVZpTlhoaGRqSnllVFpFTDBWSFRVNVdkRkl4YlZoRk5tZGxXazFSVGtWM2FsRTNkMWwxT1V0cVlqY3JTRGhPZGxsVWVFVklMM2hEWkRkelZXUnVSMFZLZDFRNUszQXJjMkZOTjBSSFpsbzNXVVJIY3pBeE1rUmFaVVJNUm10cVRVWk1URmxzVDJNek9WaFlZMU5OTlc5Rk4xUkpSVTVSTTBSaGJuZG1SWGh6V21WdmJYUlRaMnRuUlVVclJHUklaMlJITXpGeVZGbHdRMDk1VkUxaE1XZDVXakkyZEc5YWQyMDFOV1JsUmt4dkwxa3lZMlpTYnpka05EUjJUMGcwWlRsS2NsaFdWWEIwSzNsc1RHWjJNRkp0WWlJc0ltMWhZeUk2SWpNMFl6TmtZemd6T1dJNE16UXhZVFJpTVRZM1pESmhOR1E1TUROa04ySmxaR016TURNM01qRXhPVEpsTVdWaU5EVm1aalJqT1daaVkyRmlZemt3TWpJaUxDSjBZV2NpT2lJaWZRPT0=	1740777180
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: sail
--

COPY public.users (id, guid, name, email, email_verified_at, password, role, remember_token, created_at, updated_at, password_reset_token, password_reset_expires_at) FROM stdin;
1	P4K7VQ9XTYL	Ana López	ana@example.com	2025-02-28 21:18:37	$2y$12$5Bj0bSm0OEgH36myeXyvAORxV3BEPfByBZSwNtIpKvVfIyf6gacwK	admin		2025-02-28 21:18:37	2025-02-28 21:18:37	\N	\N
2	0xaL61OsDpb	Admin	admin@example.com	2025-02-28 21:18:38	$2y$12$vFYd0.hJuh7EAFSS6a9.6.pFm.y55hhTUFfwrTxtiS4SWueFAE0Vm	admin		2025-02-28 21:18:38	2025-02-28 21:18:38	\N	\N
3	2G6HueqixE5	Juan Pérez	juan@example.com	2025-02-28 21:18:38	$2y$12$5TBY5UO6ESsKcP/3OiSUDObFcdrBWU2O8TpOVPaiVx5yJsa0iyeOe	cliente		2025-02-28 21:18:38	2025-02-28 21:18:38	\N	\N
4	DU6jCZtareb	María García	maria@example.com	2025-02-28 21:18:38	$2y$12$Q/lKX8YWArzbLYpacFwWS.y1dHBGWcncEmK57Td6hr39TR99TWjUq	cliente		2025-02-28 21:18:38	2025-02-28 21:18:38	\N	\N
5	yEC3KBt6CFY	Pedro Martínez	pedro@example.com	2025-02-28 21:18:38	$2y$12$Qcu/UGhva91Q8pTzwGc5Xe364yA2VgKZzBtb28b755cRwwF7n.tii	cliente		2025-02-28 21:18:38	2025-02-28 21:18:38	\N	\N
6	X9vB7LpQ2ZM	Laura Gómez	laura@example.com	2025-02-28 21:18:39	$2y$12$GO7uF8Ysyb9nK541F6sBoetNFcVd2ieagtJ3bHn7HPJuNUgRhGU92	cliente		2025-02-28 21:18:39	2025-02-28 21:18:39	\N	\N
7	G5Yt9XqK8VL	Diego Ruiz	diego@example.com	2025-02-28 21:18:39	$2y$12$.XOMdFrncOaO1ocskLrgs.Bd1O4ZueYXyFN31rDmagqTWCFeschSS	cliente		2025-02-28 21:18:39	2025-02-28 21:18:39	\N	\N
8	J2pM6ZcQ4BR	Sofía López	sofia@example.com	2025-02-28 21:18:39	$2y$12$8e3DpaaO96msc9CYCRVSHO8sjdDxOJxDBE1xIs9kmP7Sd9jYfdYr6	cliente		2025-02-28 21:18:39	2025-02-28 21:18:39	\N	\N
9	W7Xn3TfY9KD	Javier Torres	javier@example.com	2025-02-28 21:18:39	$2y$12$uKb46JhIKc.wMf5H6iqiBun6ro8WVl1HcPB27e5zD3whbDAyeN8bq	cliente		2025-02-28 21:18:39	2025-02-28 21:18:39	\N	\N
10	P8Lq5VZK2YM	Laura Castro	laurac@example.com	2025-02-28 21:18:40	$2y$12$btLNvdc0d7mBVZzHcUHt4OoNxPk.nOjqunvTRadTM9tnHg8.9o7sG	cliente		2025-02-28 21:18:40	2025-02-28 21:18:40	\N	\N
11	M4B9XQK7YtN	Ana Lopez	analopez@example.com	2025-02-28 21:18:40	$2y$12$mxRJzWonSabRL39ppF4l6uQN5hMVSHGnDkvPP83gMHQGeBMfWsDiC	cliente		2025-02-28 21:18:40	2025-02-28 21:18:40	\N	\N
12	Z6TQ8LpX5YV	Carlos Fernandez	carlosf@example.com	2025-02-28 21:18:40	$2y$12$9rlVZmsfN5r25czpnlRSj.kIY8fYsc1jD1n6N18z7SYWE31qHmmYS	cliente		2025-02-28 21:18:40	2025-02-28 21:18:40	\N	\N
13	X9KpL3YV7QT	Isabella Rodriguez	isabellar@example.com	2025-02-28 21:18:40	$2y$12$cdrEYNYFRfYV4oPZ54RR.uVY3U8izlh/v3.r7eUant4qGpcjRpv5y	cliente		2025-02-28 21:18:40	2025-02-28 21:18:40	\N	\N
14	B6YtQ8XZ5LM	Jose Luis	joseluis@example.com	2025-02-28 21:18:41	$2y$12$dKxuQZlRRsNdMA5ZcmAX8eZ10PCMA4MQHMwY7/NgJBlMtVOJUOTGO	cliente		2025-02-28 21:18:41	2025-02-28 21:18:41	\N	\N
15	B6YtY6GPD1M	Carlos Fernández	carlos@example.com	2025-02-28 21:18:41	$2y$12$5d6mxzEvcluuOb94p5cbmuqKXque/yNWUGF6e2rELDJLaxUunpsKq	admin		2025-02-28 21:18:41	2025-02-28 21:18:41	\N	\N
16	LMAtY6GPD1M	Isabella Rodríguez	isabella@example.com	2025-02-28 21:18:41	$2y$12$.QACWtpcVhuzVvze1hsMjeWXbgrAF0P0OPmOKOZnsjgqBzhwKo50q	admin		2025-02-28 21:18:41	2025-02-28 21:18:41	\N	\N
17	PUY346GPD1M	Mario de Domingo	wolverine.mda.307@gmail.com	2025-02-28 21:18:41	$2y$12$If8C6JucXiFXiBjuznTFWeyXazxB3wmvxw8vjIdyQldSjDCKzfSbC	admin		2025-02-28 21:18:41	2025-02-28 21:18:41	\N	\N
\.


--
-- Data for Name: valoraciones; Type: TABLE DATA; Schema: public; Owner: sail
--

COPY public.valoraciones (id, guid, comentario, puntuacion, "clienteValorado_id", autor_id, created_at, updated_at) FROM stdin;
1	G7pXkT3L9qY	Excelente vendedor, muy amable.	5	2	3	2025-02-28 21:18:42	2025-02-28 21:18:42
2	vT5QmX2L8pZ	El producto llegó en buen estado, recomendado.	4	3	1	2025-02-28 21:18:42	2025-02-28 21:18:42
3	Y9XqT4L7mV3	No me gustó el trato, esperaba más comunicación.	2	1	2	2025-02-28 21:18:42	2025-02-28 21:18:42
4	L3T8pX5YqZ7	Muy buen servicio, repetiré compra.	5	2	1	2025-02-28 21:18:42	2025-02-28 21:18:42
5	X2mT7L9pQY5	Producto con detalles, pero buen vendedor.	3	2	3	2025-02-28 21:18:42	2025-02-28 21:18:42
6	T9XqY5L3pV7	Excelente trato, todo llegó a tiempo.	5	1	2	2025-02-28 21:18:42	2025-02-28 21:18:42
7	Z4pT8mX2L7Y	Muy bien, aunque la calidad podría mejorar.	3	3	1	2025-02-28 21:18:42	2025-02-28 21:18:42
8	qX7T5L9mY8V	Gran producto, pero el embalaje no fue el mejor.	4	1	3	2025-02-28 21:18:42	2025-02-28 21:18:42
9	L5mT3pX9qY7	Todo perfecto, muy recomendado.	5	2	1	2025-02-28 21:18:42	2025-02-28 21:18:42
10	X8qT7L2mY9V	El producto llegó tarde, pero en buen estado.	3	3	2	2025-02-28 21:18:42	2025-02-28 21:18:42
11	V9pX5T3L7qY	Muy satisfecho con la compra, atención excelente.	5	1	3	2025-02-28 21:18:42	2025-02-28 21:18:42
12	L2XqT8mY7pV	La calidad es buena, pero me hubiera gustado más variedad.	4	2	1	2025-02-28 21:18:42	2025-02-28 21:18:42
13	X7T9L3pY5mV	Recibí el producto con un pequeño defecto, pero me lo solucionaron rápido.	4	3	2	2025-02-28 21:18:42	2025-02-28 21:18:42
14	Y5qT2X9L8mV	Producto excelente, aunque no es lo que esperaba.	1	1	3	2025-02-28 21:18:42	2025-02-28 21:18:42
15	L8mT5X7pY9q	Todo llegó a tiempo y en perfectas condiciones.	1	2	1	2025-02-28 21:18:42	2025-02-28 21:18:42
16	A1B2C3D4E5	Servicio excepcional, muy recomendable.	5	1	2	2025-02-28 21:18:42	2025-02-28 21:18:42
17	F6G7H8I9J0	Entrega rápida, aunque el embalaje podría mejorar.	4	2	3	2025-02-28 21:18:42	2025-02-28 21:18:42
18	K1L2M3N4O5	Producto en perfecto estado, muy contento.	5	3	4	2025-02-28 21:18:42	2025-02-28 21:18:42
19	P6Q7R8S9T0	Atención al cliente muy buena, repetiré.	5	4	5	2025-02-28 21:18:42	2025-02-28 21:18:42
20	U1V2W3X4Y5	Hubo un retraso, pero se solucionó rápido.	3	5	6	2025-02-28 21:18:42	2025-02-28 21:18:42
21	Z6A7B8C9D0	No me gustó el trato, esperaba más comunicación.	2	6	7	2025-02-28 21:18:42	2025-02-28 21:18:42
22	E1F2G3H4I5	Muy atento el vendedor, calidad buena.	4	7	8	2025-02-28 21:18:42	2025-02-28 21:18:42
23	J6K7L8M9N0	Producto con defectos, esperaba más.	2	8	9	2025-02-28 21:18:42	2025-02-28 21:18:42
24	O1P2Q3R4S5	Entrega puntual y en perfectas condiciones.	5	9	10	2025-02-28 21:18:42	2025-02-28 21:18:42
25	T6U7V8W9X0	El precio es justo para la calidad recibida.	4	10	11	2025-02-28 21:18:42	2025-02-28 21:18:42
26	Y1Z2A3B4C5	Atención amable, aunque algo demorada.	3	11	12	2025-02-28 21:18:42	2025-02-28 21:18:42
27	D6E7F8G9H0	Calidad excepcional, repetiré sin duda.	5	12	1	2025-02-28 21:18:42	2025-02-28 21:18:42
\.


--
-- Data for Name: ventas; Type: TABLE DATA; Schema: public; Owner: sail
--

COPY public.ventas (id, guid, estado, comprador, "lineaVentas", "precioTotal", created_at, updated_at) FROM stdin;
1	kY8XqT5L9v3	procesado	{"guid":"DU6jCZtareb","id":2,"nombre":"Maria","apellido":"Garcia"}	[{"vendedor":{"guid":"2G6HueqixE5","id":1,"nombre":"Juan","apellido":"Perez"},"cantidad":2,"producto":{"guid":"G4YXT9K5QLV","id":1,"nombre":"Portatil Gamer","descripcion":"Portatil gaming de gama alta para trabajos pesados.","estadoFisico":"Nuevo","precio":800,"categoria":"Tecnologia"},"precioTotal":1600}]	1600	2025-02-28 21:18:42	2025-02-28 21:18:42
2	Z4mT7pQX2Vy	procesado	{"guid":"yEC3KBt6CFY","id":3,"nombre":"Pedro","apellido":"Martinez"}	[{"vendedor":{"guid":"2G6HueqixE5","id":1,"nombre":"Juan","apellido":"Perez"},"cantidad":1,"producto":{"guid":"VYQ8XK4T9L5","id":4,"nombre":"Pantalones Vaqueros","descripcion":"Pantalones Vaqueros c\\u00f3modos.","estadoFisico":"Nuevo","precio":10,"categoria":"Ropa"},"precioTotal":10},{"vendedor":{"guid":"DU6jCZtareb","id":2,"nombre":"Maria","apellido":"Garcia"},"cantidad":2,"producto":{"guid":"T3K9QLYV7X5","id":5,"nombre":"Mario Party 8","descripcion":"Juego de plataformas y acci\\u00f3n, muy popular en Nintendo.","estadoFisico":"Nuevo","precio":50,"categoria":"Videojuegos"},"precioTotal":100}]	110	2025-02-28 21:18:42	2025-02-28 21:18:42
\.


--
-- Name: cliente_favoritos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sail
--

SELECT pg_catalog.setval('public.cliente_favoritos_id_seq', 1, false);


--
-- Name: clientes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sail
--

SELECT pg_catalog.setval('public.clientes_id_seq', 12, true);


--
-- Name: failed_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sail
--

SELECT pg_catalog.setval('public.failed_jobs_id_seq', 1, false);


--
-- Name: jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sail
--

SELECT pg_catalog.setval('public.jobs_id_seq', 1, false);


--
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sail
--

SELECT pg_catalog.setval('public.migrations_id_seq', 8, true);


--
-- Name: productos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sail
--

SELECT pg_catalog.setval('public.productos_id_seq', 21, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sail
--

SELECT pg_catalog.setval('public.users_id_seq', 17, true);


--
-- Name: valoraciones_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sail
--

SELECT pg_catalog.setval('public.valoraciones_id_seq', 27, true);


--
-- Name: ventas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sail
--

SELECT pg_catalog.setval('public.ventas_id_seq', 2, true);


--
-- Name: cache_locks cache_locks_pkey; Type: CONSTRAINT; Schema: public; Owner: sail
--

ALTER TABLE ONLY public.cache_locks
    ADD CONSTRAINT cache_locks_pkey PRIMARY KEY (key);


--
-- Name: cache cache_pkey; Type: CONSTRAINT; Schema: public; Owner: sail
--

ALTER TABLE ONLY public.cache
    ADD CONSTRAINT cache_pkey PRIMARY KEY (key);


--
-- Name: cliente_favoritos cliente_favoritos_pkey; Type: CONSTRAINT; Schema: public; Owner: sail
--

ALTER TABLE ONLY public.cliente_favoritos
    ADD CONSTRAINT cliente_favoritos_pkey PRIMARY KEY (id);


--
-- Name: clientes clientes_guid_unique; Type: CONSTRAINT; Schema: public; Owner: sail
--

ALTER TABLE ONLY public.clientes
    ADD CONSTRAINT clientes_guid_unique UNIQUE (guid);


--
-- Name: clientes clientes_pkey; Type: CONSTRAINT; Schema: public; Owner: sail
--

ALTER TABLE ONLY public.clientes
    ADD CONSTRAINT clientes_pkey PRIMARY KEY (id);


--
-- Name: failed_jobs failed_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: sail
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_pkey PRIMARY KEY (id);


--
-- Name: failed_jobs failed_jobs_uuid_unique; Type: CONSTRAINT; Schema: public; Owner: sail
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_uuid_unique UNIQUE (uuid);


--
-- Name: job_batches job_batches_pkey; Type: CONSTRAINT; Schema: public; Owner: sail
--

ALTER TABLE ONLY public.job_batches
    ADD CONSTRAINT job_batches_pkey PRIMARY KEY (id);


--
-- Name: jobs jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: sail
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_pkey PRIMARY KEY (id);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: sail
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: sail
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_pkey PRIMARY KEY (email);


--
-- Name: productos productos_guid_unique; Type: CONSTRAINT; Schema: public; Owner: sail
--

ALTER TABLE ONLY public.productos
    ADD CONSTRAINT productos_guid_unique UNIQUE (guid);


--
-- Name: productos productos_pkey; Type: CONSTRAINT; Schema: public; Owner: sail
--

ALTER TABLE ONLY public.productos
    ADD CONSTRAINT productos_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: sail
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: sail
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- Name: users users_guid_unique; Type: CONSTRAINT; Schema: public; Owner: sail
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_guid_unique UNIQUE (guid);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: sail
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: valoraciones valoraciones_guid_unique; Type: CONSTRAINT; Schema: public; Owner: sail
--

ALTER TABLE ONLY public.valoraciones
    ADD CONSTRAINT valoraciones_guid_unique UNIQUE (guid);


--
-- Name: valoraciones valoraciones_pkey; Type: CONSTRAINT; Schema: public; Owner: sail
--

ALTER TABLE ONLY public.valoraciones
    ADD CONSTRAINT valoraciones_pkey PRIMARY KEY (id);


--
-- Name: ventas ventas_guid_unique; Type: CONSTRAINT; Schema: public; Owner: sail
--

ALTER TABLE ONLY public.ventas
    ADD CONSTRAINT ventas_guid_unique UNIQUE (guid);


--
-- Name: ventas ventas_pkey; Type: CONSTRAINT; Schema: public; Owner: sail
--

ALTER TABLE ONLY public.ventas
    ADD CONSTRAINT ventas_pkey PRIMARY KEY (id);


--
-- Name: jobs_queue_index; Type: INDEX; Schema: public; Owner: sail
--

CREATE INDEX jobs_queue_index ON public.jobs USING btree (queue);


--
-- Name: sessions_last_activity_index; Type: INDEX; Schema: public; Owner: sail
--

CREATE INDEX sessions_last_activity_index ON public.sessions USING btree (last_activity);


--
-- Name: sessions_user_id_index; Type: INDEX; Schema: public; Owner: sail
--

CREATE INDEX sessions_user_id_index ON public.sessions USING btree (user_id);


--
-- Name: cliente_favoritos cliente_favoritos_cliente_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: sail
--

ALTER TABLE ONLY public.cliente_favoritos
    ADD CONSTRAINT cliente_favoritos_cliente_id_foreign FOREIGN KEY (cliente_id) REFERENCES public.clientes(id) ON DELETE CASCADE;


--
-- Name: cliente_favoritos cliente_favoritos_producto_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: sail
--

ALTER TABLE ONLY public.cliente_favoritos
    ADD CONSTRAINT cliente_favoritos_producto_id_foreign FOREIGN KEY (producto_id) REFERENCES public.productos(id) ON DELETE CASCADE;


--
-- Name: clientes clientes_usuario_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: sail
--

ALTER TABLE ONLY public.clientes
    ADD CONSTRAINT clientes_usuario_id_foreign FOREIGN KEY (usuario_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: productos productos_vendedor_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: sail
--

ALTER TABLE ONLY public.productos
    ADD CONSTRAINT productos_vendedor_id_foreign FOREIGN KEY (vendedor_id) REFERENCES public.clientes(id) ON DELETE CASCADE;


--
-- Name: valoraciones valoraciones_autor_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: sail
--

ALTER TABLE ONLY public.valoraciones
    ADD CONSTRAINT valoraciones_autor_id_foreign FOREIGN KEY (autor_id) REFERENCES public.clientes(id) ON DELETE CASCADE;


--
-- Name: valoraciones valoraciones_clientevalorado_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: sail
--

ALTER TABLE ONLY public.valoraciones
    ADD CONSTRAINT valoraciones_clientevalorado_id_foreign FOREIGN KEY ("clienteValorado_id") REFERENCES public.clientes(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

